import React from 'react'
import "./FitnessStart.css"

export default function Fitnessstart() {
  return (
    <div className='fitnessstart'>

        <div className='fitnessstartcontainer'>
            <h2>Get all the fitness solution for all the kind of platforms</h2>
            <button className='szstartbtn'>Let's Get Started</button>
        </div>
    </div>
  )
}
