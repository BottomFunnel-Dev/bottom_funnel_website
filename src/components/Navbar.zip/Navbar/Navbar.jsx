import React from "react";
import { useState } from "react";
import "./navbar.css";
import { IoIosPeople } from "react-icons/io";
import { IconContext } from "react-icons";
import { RiTeamFill } from "react-icons/ri";

const Navbar = () => {
  const [aboutH, setAboutH] = useState(false);
  const [solution, setSolution] = useState(false);
  const [service, setService] = useState(false);
  const [handleCat, setHandleCat] = useState(true);
  const [navbar, setNabvar] = useState(false);

  const solHoverIn = () => {
    setSolution(true);
    setNabvar(true);
  };
  const solHoverOut = () => {
    setSolution(false);
    setNabvar(false);
  };
  const serHoverIn = () => {
    setService(true);
    setNabvar(true);
  };
  const serHoverOut = () => {
    setService(false);
    setNabvar(false);
  };
  const homeHoverIn = () => {
    setAboutH(true);
    setNabvar(true);
  };
  const homeHoverOut = () => {
    setAboutH(false);
    setNabvar(false);
  };

  const handleCategory = () => {
    handleCat ? setHandleCat(false) : setHandleCat(true);
  };

  const navBackground = () => {
    if (window.scrollY > 1) {
      setNabvar(true);
    } else {
      setNabvar(false);
    }
  };
  window.addEventListener("scroll", navBackground);
  return (
    <div>
      <nav className={navbar ? "navbarSection active" : "navbarSection"}>
        <ul>
          <li id="logo">
            <img src={navbar?'Images/funnel.png':'Images/logowhite.png'} alt="" />
            <h4>Bottom Funnel</h4>
            {/* <img src={funnelText} alt="" /> */}
          </li>
        </ul>
        <ul>
          <li onMouseEnter={homeHoverIn} onMouseLeave={homeHoverOut}>
            ABOUT
          </li>
          <li onMouseEnter={solHoverIn} onMouseLeave={solHoverOut}>
            SOLUTIONS
          </li>
          <li onMouseEnter={serHoverIn} onMouseLeave={serHoverOut}>
            SERVICES
          </li>
          <li>PORTFOLIO</li>
          <li>BLOG</li>
          <li>PRODUCTS</li>
          <li>CLIENTS</li>
          <li className="callToAction">Get Started</li>
          <li className="callToAction">Get Started</li>
        </ul>
      </nav>
      <div
        onMouseEnter={homeHoverIn}
        onMouseLeave={homeHoverOut}
        className={aboutH ? "aboutNavVisible" : "aboutNavInvisible"}
      >
        <div className="aboutLeft">
          <div>
            <div>
              <IconContext.Provider value={{ className: "listIconFirst" }}>
                <IoIosPeople />
              </IconContext.Provider>
              <p>Our Company</p>
            </div>
            <div>
              <IconContext.Provider value={{ className: "listIconFirst" }}>
                <RiTeamFill />
              </IconContext.Provider>
              <p>How we work</p>
            </div>
            <div>
              <IconContext.Provider value={{ className: "listIconFirst" }}>
                <IoIosPeople />
              </IconContext.Provider>
              <p>Core team</p>
            </div>
            <div>
              <IconContext.Provider value={{ className: "listIconFirst" }}>
                <IoIosPeople />
              </IconContext.Provider>
              <p>Agile development</p>
            </div>
            <div>
              <IconContext.Provider value={{ className: "listIconFirst" }}>
                <IoIosPeople />
              </IconContext.Provider>
              <p>Career</p>
            </div>
          </div>
          <div>
            <div>
              <IconContext.Provider value={{ className: "listIcon" }}>
                <IoIosPeople />
              </IconContext.Provider>
              <div className="innerList">
                <p>Full cycle product development </p>
                <ul>
                  <li>Product management</li>
                  <li>MVP</li>
                  <li>Startups</li>
                  <li>Enterprise</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="aboutRight"></div>
      </div>

      <div
        onMouseEnter={solHoverIn}
        onMouseLeave={solHoverOut}
        className={solution ? "solutionVisible" : "solutionInvisible"}
      >
        <div className="solutionCat">
          <p
            className={handleCat ? "backgroundP" : "backgroundPNone"}
            onClick={handleCategory}
          >
            ON DEMAND APP
          </p>
          <p
            className={handleCat ? "backgroundPNone" : "backgroundP"}
            onClick={handleCategory}
          >
            INDUSTRIES
          </p>
        </div>
        <div className={handleCat ? "solutionType" : "displayNone"}>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Food Delivery App</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Grocery Delivery App</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Pickup & Delivery</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Taxi Booking App</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>On Demand Home Services</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Beauty & Salon App</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Pharmacy Delivery App</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Tool Delivery App</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Alcohol Delivery App</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Cannabis Delivery App</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Flower Delivery App</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Ice Cream Delivery App</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Laundry Delivery</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Marketplace Apps</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Carpooling Apps</p>
          </div>
          <div></div>
        </div>
        <div className={handleCat ? "displayNone" : "solutionTypeIndustries"}>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Education</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Video Streaming</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Fitness</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Social Media</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Game Development</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Sports Betting</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Dating</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Logistics</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>E-commerce</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>IOT Development</p>
          </div>
          <div>
            <IconContext.Provider value={{ className: "listIconFirst" }}>
              <IoIosPeople />
            </IconContext.Provider>
            <p>Cryptocurrency</p>
          </div>
        </div>
      </div>
      <div
        onMouseEnter={serHoverIn}
        onMouseLeave={serHoverOut}
        className={service ? "serviceVisible" : "serviceInvisible"}
      >
        <div className="serviceCat"></div>
        <div className="serviceType"></div>
      </div>
    </div>
  );
};

export default Navbar;
