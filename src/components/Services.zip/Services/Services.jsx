import React, { useState } from "react";
import "./services.css";
import { FaMobileAlt } from "react-icons/fa";
import { IconContext } from "react-icons/lib";

const Services = () => {
  let arr = [
    { name: "1" },
    { name: "2" },
    { name: "3" },
    { name: "4" },
    { name: "5" },
    { name: "6" },
    { name: "7" },
    { name: "8" },
  ];
  const [servicesToggle, setServiceToggle] = useState(false);
  const [num, setNum] = useState();

  const mouseInFunc = (i) => {
    setNum(i);
    setServiceToggle(true);
  };

  const mouseOutFunc = () => {
    setServiceToggle(false);
  };

  return (
    <>
      <h1>Our Services</h1>

      <div className="services">
        {arr.map((item, i) => (
          <div
            key={i}
            onMouseLeave={() => mouseOutFunc(i)}
            onMouseEnter={() => {
              mouseInFunc(i);
            }}
          >
            <div
              className={
                servicesToggle && num == i
                  ? "serviceHeadingFullPart"
                  : "serviceHeadingPart"
              }
            >
              <IconContext.Provider value={{className:servicesToggle && num == i? "iconClassNone": "iconClass"}} ><FaMobileAlt fontSize="50px" /></IconContext.Provider>
              <h2>MOBILE & WEARABLES</h2>
              <div className="supportableDevices">
                <li>IOS</li>
                <li>IOS</li>
                <li>IOS</li>
                <li>IOS</li>
                <li>IOS</li>
              </div>
            </div>

            <div
              className={
                servicesToggle && num == i
                  ? "serviceDescriptionVisible"
                  : "serviceDescriptionInvisible"
              }
            >
              <p>
                Our mobile app development services offer modern, feature-rich
                solutions for iOS, Android and cross-platform mobile apps. We
                also build amazing wearable solutions.
              </p>
              <p>READ MORE</p>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default Services;
