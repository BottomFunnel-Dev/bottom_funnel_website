import React from "react";
import "./nodjsBannerNav.css";

export const NodejsBannerNavigation = () => {
  return (
    <div className="nodejs-banner-nav-main">
      <ul>
        <li>Hello</li>
        <li>World</li>
      </ul>
    </div>
  );
};
