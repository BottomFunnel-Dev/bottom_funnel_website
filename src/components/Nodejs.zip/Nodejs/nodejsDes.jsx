import React from "react";
import "./nodejsDes.css";

export const NodejsDescription = () => {
  return (
    <div className="nodejs-des-main">
      <div className="nodejs-des-content">
        <h1>Node js</h1>
        <p>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry's standard dummy text ever
          since the 1500s.Lorem Ipsum is simply dummy text of the printing and
          typesetting industry. Lorem Ipsum has been the industry's standard
          dummy text ever since the 1500s.Lorem Ipsum is simply dummy text of
          the printing and typesetting industry. Lorem Ipsum has been the
          industry's standard dummy text ever since the 1500s.
        </p>
      </div>
      <img src="Images/nodejsphotos/js-logo-new.png" alt="Nodejs logo" />
    </div>
  );
};
